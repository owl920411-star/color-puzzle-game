#!/usr/bin/env python3
"""Apply explicit event hooks to the verified DEV snapshot. No network or git writes.
Default: dry run. --apply writes files only; never commits/pushes/deploys.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, shutil, tempfile
BASE_COMMIT = '9145150c1f42409926ee31ef59bc6010a62fd2c4'
APP_SHA = '2d3310e38fe241ddde8215faafc0fb684bebb410'
INDEX_SHA = 'baad256ef77f977e422d864fb56a2124e8395ab5'
PACKAGE = Path(__file__).resolve().parents[1]
MARK = '/* ADAPTIVE DIRECTOR V1 HOOKS */'

def git_blob(raw):
    return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def patch_app(text):
    if MARK in text:
        raise ValueError('Already applied. Do not layer the patch twice.')
    def rep(old, new, count=1):
        nonlocal text
        actual = text.count(old)
        if actual != count:
            raise ValueError(f'Anchor mismatch: expected {count}, got {actual}: {old[:100]!r}')
        text = text.replace(old, new)

    rep("let desert, itemSystem=B.state('preview'),relicReturn='game';",
        "let desert, itemSystem=B.state('preview'),relicReturn='game';\n"+MARK+"\nlet adaptive=null;\nfunction adaptiveRecordKey(){return kind==='normal'?(adaptive?.recordKey()||'normal'):kind;}\n")
    rep("function markPractice(){itemSystem.practice=true;recordBest=initialBest;}",
        "function markPractice(){itemSystem.practice=true;adaptive?.exclude();recordBest=initialBest;}")
    rep("if(kind!=='normal'||practice())return;const sec=", "if(kind!=='normal'||practice()||adaptive?.guest)return;const sec=")
    rep("s.desertSurvival=object(s.desertSurvival);const d=s.desertSurvival;",
        "const key=adaptive?.desertKey()||'desertSurvival';s[key]=object(s[key]);const d=s[key];")
    rep("emitNormal({...p,rows:tx.scoringRows},result);announceItems(tx.events);return result;",
        "adaptive?.resolved(p,tx);emitNormal({...p,rows:tx.scoringRows},result);announceItems(tx.events);return result;")
    rep("function itemTick(){if(kind!=='normal'||!itemSystem.enabled||state!=='playing')return;announceItems(B.expire(run,itemSystem,elapsed));}",
        "function itemTick(){if(kind!=='normal'||!itemSystem.enabled||state!=='playing')return;const before=adaptive?.board(),events=B.expire(run,itemSystem,elapsed);if(events.length)adaptive?.system('item',before);announceItems(events);}")
    rep("if(key==='hourglass')desert.delay=Math.min(15000,desert.delay+10000);",
        "const adaptiveBefore=adaptive?.board();\n if(key==='hourglass')desert.delay=Math.min(15000,desert.delay+10000);")
    rep("desert.inventory[key]--;callout(RELIC_NAMES[key],", "desert.inventory[key]--;adaptive?.system('relic',adaptiveBefore);callout(RELIC_NAMES[key],")
    rep("return false;const source=B.clone(run.board),holes=", "return false;const adaptiveBefore=adaptive?.board();const source=B.clone(run.board),holes=")
    rep("run.board=source;run.active=p;desert.previewHoles=null;", "run.board=source;run.active=p;adaptive?.system('ground',adaptiveBefore);desert.previewHoles=null;")
    rep("if(riseGround())desert.nextRise=elapsed+cfg.interval;",
        "if(riseGround()){const next=adaptive?.interval(cfg.interval)??cfg.interval;desert.nextRise=elapsed+next;desert.adaptiveInterval=next;}")
    rep("function loadBest(){recordBest=finite(object(object(readStore().endlessV1)[kind]).best);initialBest=recordBest;}",
        "function loadBest(){recordBest=finite(object(object(readStore().endlessV1)[adaptiveRecordKey()]).best);initialBest=recordBest;}")
    rep("if(!run||state==='menu')return;if(practice()){lastSave=performance.now();return;}",
        "if(!run||state==='menu')return;if(practice()||adaptive?.guest){lastSave=performance.now();return;}")
    rep("const r=object(s.endlessV1[kind]);", "const key=adaptiveRecordKey(),r=object(s.endlessV1[key]);")
    rep("s.endlessV1[kind]=r;", "s.endlessV1[key]=r;")
    rep("function menu(){\n", "function menu(){\n adaptive?.end('menu');\n")
    rep("function start(retry=false){\n", "function start(retry=false){\n adaptive?.end('restart');\n")
    rep("loadBest();if(kind==='normal')maybeSeedNextItem();", "adaptive?.begin();loadBest();if(kind==='normal')maybeSeedNextItem();")
    rep("function finish(){\n", "function finish(){\n if(state!=='over')adaptive?.end('gameover');\n")
    rep("const ds=object(readStore().desertSurvival);", "const ds=object(readStore()[adaptive?.desertKey()||'desertSurvival']);")
    # Guest text never implies that this session was saved.
    rep("${practice()?'개발자 조작을 사용한 판은 최고 기록에 저장되지 않습니다.':saveOK?",
        "${adaptive?.guest?'임시 플레이는 기록과 개인 프로필에 저장하지 않습니다.':practice()?'개발자 조작을 사용한 판은 최고 기록에 저장되지 않습니다.':saveOK?")
    rep("function lockNormal(keep=false){\n if(!run.active)return;if(!keep)clearInput();",
        "function lockNormal(keep=false){\n if(!run.active)return;adaptive?.beforeLock();if(!keep)clearInput();")
    rep("run.lock();B.arm(run.board,elapsed);", "run.lock();adaptive?.locked();B.arm(run.board,elapsed);")
    rep("else{run.noClear();nextNormal();}", "else{run.noClear();adaptive?.resolved(null,null);nextNormal();}")
    rep("run.move(0,d);run.score+=d*2;tone('drop');lockNormal(keep);", "adaptive?.input('drop',true);run.move(0,d);run.score+=d*2;tone('drop');lockNormal(keep);")
    rep("if(moved&&grounded&&lockResets<12", "adaptive?.input(a,moved);if(moved&&grounded&&lockResets<12")
    rep("if(!playing()||hitStop)return;elapsed+=dt;", "if(!playing()||hitStop)return;elapsed+=dt;adaptive?.tick(raw);")
    rep("if(n===4&&cfg.lv>0){desert.delay=Math.min(15000,desert.delay+5000);",
        "if(n===4&&cfg.lv>0){adaptive?.system('relic');desert.delay=Math.min(15000,desert.delay+5000);")
    # Read-only menu additions, no canvas input or rail CSS changes.
    rep('<div class="kicker">HOW TO PLAY</div><h2>${name()} 모드</h2>',
        '<div class="kicker">HOW TO PLAY</div><h2>${name()} 모드</h2>${adaptive?.button()||\'\'}')
    rep('<div class="kicker">DEV LAB · BLOCK ITEMS V2</div><h2>블록 아이템 테스트</h2>',
        '<div class="kicker">DEV LAB · BLOCK ITEMS V2</div><h2>블록 아이템 테스트</h2>${adaptive?.button()||\'\'}')
    rep("window.addEventListener('pagehide',()=>{rememberScore();clearInput();});",
        "window.addEventListener('pagehide',()=>{rememberScore();adaptive?.end('interrupted',true);clearInput();});")
    rep("else if(a==='back'){if(overlayView==='relic')", "else if(a==='back'){if(overlayView==='adaptive'){adaptive?.back();}else if(overlayView==='relic')")
    rep("menu();fit();$('boot').hidden=true;", INIT+"\nmenu();fit();$('boot').hidden=true;")
    rep("get elapsed(){return elapsed;},action,update,start,", "get elapsed(){return elapsed;},get adaptive(){return adaptive;},action,update,start,")
    return text

INIT = r"""
if(window.AdaptiveBridge&&window.AdaptiveDirector)adaptive=window.AdaptiveBridge.create({
 storage:{getItem:k=>localStorage.getItem(k),setItem:(k,v)=>localStorage.setItem(k,v)},panel,
 get:()=>({run,kind,state,desert,elapsed,seed:currentSeed,practice:practice(),overlayView,
  baseInterval:desertCfg().interval,interval:desert?.adaptiveInterval||desertCfg().interval}),
 curses:()=>kind==='normal'?findSpecials().filter(q=>DESERT_ITEMS[q.s.type].kind==='bad'&&!q.s.failed).length:0,
 show:showPanel,
 pauseForPanel:()=>{if(playing()){beforePause=state;state='paused';clearInput();rememberScore();}document.body.classList.remove('ground-warning');},
 back:view=>{if(view==='dev')devPanel();else if(view==='settings')settings();else if(view==='pause')pausePanel();else if(view==='menu'||state==='menu')showMenu();else if(state==='paused')resume();else showMenu();},
 download:(filename,text)=>{const blob=new Blob([text],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
});
"""

def patch_index(text):
    old='<script src="endless-app.js?v=block-v2"></script>'
    if text.count(old)!=1: raise ValueError('Index script anchor changed')
    text=text.replace(old, '<script src="adaptive-director.js?v=adaptive1"></script>\n<script src="adaptive-bridge.js?v=adaptive1"></script>\n<script src="endless-app.js?v=adaptive1"></script>')
    return text.replace('CONTROL 16 · NOVICE 7 · BLOCK ITEMS V2</small>', 'CONTROL 16 · NOVICE 7 · BLOCK ITEMS V2 · ADAPTIVE 1</small>')

def run(root, apply=False):
    root=root.resolve()
    branch=subprocess.check_output(['git','-C',str(root),'branch','--show-current'],text=True).strip()
    if branch!='dev':raise ValueError(f'Only dev may be modified; current branch: {branch!r}')
    app=(root/'dist/endless-app.js').read_bytes(); index=(root/'dist/index.html').read_bytes()
    if git_blob(app)!=APP_SHA or git_blob(index)!=INDEX_SHA:
        raise ValueError('Source blob differs from verified baseline. Do not overwrite: review and rebase the patch.')
    original=app.decode('utf-8'); changed=patch_app(original)
    # Preserve all gesture parsing/pointer handlers byte for byte.
    a="function fastDown("; b="for(const b of document.querySelectorAll('[data-preview]'))"
    if original[original.index(a):original.index(b)]!=changed[changed.index(a):changed.index(b)]:
        raise ValueError('Input handlers unexpectedly changed')
    files={'dist/endless-app.js':changed.encode(), 'dist/index.html':patch_index(index.decode()).encode()}
    for path in ['dist/adaptive-director.js','dist/adaptive-bridge.js','tests/adaptive-director.test.cjs','tests/adaptive-bridge.test.cjs','docs/ADAPTIVE-DIRECTOR-V1-IMPLEMENTATION.md','docs/ADAPTIVE-DIRECTOR-V1-APPROVED-DRAFT.md','docs/ADAPTIVE-TEST-RESULTS.txt']:
        if (root/path).exists():raise ValueError(f'New target already exists: {path}')
        files[path]=(PACKAGE/path).read_bytes()
    node=shutil.which('node')
    if not node:raise ValueError('Node is required for pre-write syntax checks')
    with tempfile.TemporaryDirectory() as temp:
        for path,data in files.items():
            if path.endswith(('.js','.cjs')):
                f=Path(temp)/Path(path).name;f.write_bytes(data)
                subprocess.run([node,'--check',str(f)],check=True,capture_output=True)
    if not apply:
        print('DRY RUN OK: verified baseline; syntax OK; gestures unchanged. No files written.')
        print('\n'.join(files));return
    originals={path:(root/path).read_bytes() if (root/path).exists() else None for path in files}
    try:
        for path,data in files.items():
            p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    except Exception:
        for path,data in originals.items():
            p=root/path
            if data is None:p.unlink(missing_ok=True)
            else:p.write_bytes(data)
        raise
    print('LOCAL DEV FILES UPDATED. No commit, push or deployment has been performed.')
    print('Run: node --test tests/adaptive-*.test.cjs tests/block-items*.test.cjs')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('repository',type=Path);parser.add_argument('--apply',action='store_true');args=parser.parse_args()
    try:run(args.repository,args.apply)
    except (ValueError,OSError,subprocess.CalledProcessError) as e:raise SystemExit('SAFE STOP: '+str(e))

# GLASSFALL 개인 맞춤 난이도 — 적용 패키지

**로컬 코드/신규 모듈 테스트 완료. 아직 GitHub에 업로드되거나 Cloudflare에 배포되지 않았습니다.**

현재 확인한 DEV: `9145150c1f42409926ee31ef59bc6010a62fd2c4`.
기본 모드는 **관찰만**입니다. 게임을 자동으로 어렵게 만들지 않습니다.

## 담긴 파일

`dist/adaptive-director.js`: 유효 배치·자연 줄·빈칸·높이 기반 판정.
`dist/adaptive-bridge.js`: 설정·진단·프로필·기록·게임 연결 인터페이스.
`tools/apply_adaptive.py`: 현재 DEV 코드에 정확한 연결 지점을 추가하는 적용기.
`tests/adaptive-*.test.cjs`: 실제 실행해서 통과한 신규 테스트 52개.
`docs/`: 승인 기획 원본, 구현/미검증 항목, 테스트 로그.

## 적용 담당자용

압축은 저장소 **바깥**의 별도 폴더에 풀어주세요. Node와 Python 3이 필요합니다.

```bash
# 새 모듈 테스트 — 저장소 없이도 실행됩니다.
node --test tests/adaptive-*.test.cjs

# DEV 작업공간 대상으로 먼저 안전 검사 (읽기만 합니다).
python tools/apply_adaptive.py /path/to/color-puzzle-game

# 검사가 통과한 경우 파일에 반영합니다. 커밋/push는 하지 않습니다.
python tools/apply_adaptive.py /path/to/color-puzzle-game --apply

# 실제 작업공간에서 기존 블록 시스템과 함께 검사합니다.
cd /path/to/color-puzzle-game
node --test tests/adaptive-*.test.cjs tests/block-items*.test.cjs
```

dev 브랜치가 아니거나 원본 앱/HTML SHA가 다르면 적용기는 중지합니다. main에서는 실행되지 않습니다. 오류를 무시하거나 SHA 확인을 제거하지 마세요. GitHub 커밋과 Cloudflare 배포는 별도 작업입니다.

## 화면에서 사용하는 경로 (적용 후)

`점수 규칙·설정 → 개인 맞춤 난이도` 또는 `하단 버전 글자 → DEV LAB → 개인 맞춤 난이도`.

처음에는 `관찰만`으로 플레이합니다. 판단 화면에서 실제 적용은 ×1, 제안은 따로 표시됩니다. `자동 조절`을 선택해 새 판을 시작해야 지반 주기 조절이 실제로 켜집니다. 설정을 바꾸어도 현재 판은 바뀌지 않습니다. 새 판은 항상 ×1부터 시작하며 현재 예고한 지반 상승을 앞당기지 않습니다.

## 개발 계획을 보존하는 기준 문서

`docs/ADAPTIVE-DIRECTOR-V1-IMPLEMENTATION.md`.

52개 통과는 새 모듈/연결 포트 검사이며 실제 게임 전체 통합이나 사람 평균·7분 생존을 검증한 결과가 아닙니다. 아직 원격 DEV는 변경되지 않았습니다.
